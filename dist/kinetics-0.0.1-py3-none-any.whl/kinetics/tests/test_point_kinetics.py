"""Unittests for the inhour module"""

import numpy

from ntptransient import reactor, reactivity
from ntptransient.config import Configs


