# -*- coding: utf-8 -*-
"""
Created on Sun Feb  4 18:18:30 2024

function contains basic utility functions used across the package

@author: matt krecicki
@email: matthewkrecicki@gmail.com
"""


import numpy as np

def l2norm(x0, x1):
    
    return 0.0
