# kinetics
A python package for reduced order modeling of reactor kinetics
